// An isolated browser context; never reads or edits the user's browser profile.
import {chromium} from '@playwright/test';
import {existsSync} from 'node:fs';
import assert from 'node:assert/strict';
const executablePath=process.env.BROWSER_EXECUTABLE??['C:/Program Files/Google/Chrome/Application/chrome.exe','C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'].find(existsSync);
const browser=await chromium.launch({headless:true,chromiumSandbox:true,...(executablePath?{executablePath}:{})});
const keepAlive=setInterval(()=>{},1000);
try{
 const context=await browser.newContext({viewport:{width:390,height:844},locale:'en-GB',serviceWorkers:'allow'});
 const page=await Promise.race([context.newPage(),new Promise((_,reject)=>setTimeout(()=>reject(Error('The isolated browser did not create a test page.')),20000))]);const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:4173/?test');
 await page.getByRole('textbox',{name:'Weight',exact:true}).waitFor();
 assert.equal(await page.getByRole('textbox',{name:'Weight',exact:true}).inputValue(),'105.0');
 assert.equal(await page.getByRole('textbox',{name:'Steps',exact:true}).inputValue(),'');
 await page.getByRole('textbox',{name:'Calories',exact:true}).fill('1850');
 await page.getByRole('textbox',{name:'Steps',exact:true}).fill('8420');
 await page.getByRole('button',{name:'Finish day',exact:true}).click();
 await page.waitForFunction(()=>!!navigator.serviceWorker.controller);
 await context.setOffline(true);
 await page.reload({waitUntil:'domcontentloaded'});
 await page.getByRole('button',{name:'Reopen day',exact:true}).waitFor();
 assert.equal(await page.getByRole('textbox',{name:'Calories',exact:true}).inputValue(),'1850');
 assert.equal(await page.getByRole('textbox',{name:'Steps',exact:true}).inputValue(),'8420');
 await page.getByRole('button',{name:'Reopen day',exact:true}).click();
 await page.getByRole('textbox',{name:'Steps',exact:true}).fill('9000');
 await page.reload({waitUntil:'domcontentloaded'});
 assert.equal(await page.getByRole('textbox',{name:'Steps',exact:true}).inputValue(),'9000');
 assert.equal(await page.getByRole('textbox',{name:'Calories',exact:true}).inputValue(),'1850');
 assert.deepEqual(errors,[]);
 await context.setOffline(false);
 await page.getByRole('button',{name:'Settings',exact:true}).click();
 const manifest=await(await context.request.get('http://127.0.0.1:4173/manifest.webmanifest')).json();
 assert.equal(manifest.name,'Still I Rise');assert.equal(manifest.display,'standalone');assert.equal(manifest.icons.length,3);
 const layouts=[];
 for(const size of [{width:375,height:667},{width:390,height:844},{width:430,height:932},{width:1440,height:900}]){
  await page.setViewportSize(size);
  for(const name of ['Today','Dashboard','Trends','History','Settings']){
   await page.getByRole('button',{name,exact:true}).click();
   const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth);
   assert.equal(overflow,false,`${name} overflows ${size.width}`);layouts.push({width:size.width,page:name,overflow});
  }
 }
 console.log(JSON.stringify({offlineReload:true,offlineLogging:true,offlinePersistence:true,manifest:true,layouts,runtimeErrors:errors},null,2));
}finally{clearInterval(keepAlive);await browser.close()}
