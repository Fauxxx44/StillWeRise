import{readdir,writeFile}from'node:fs/promises';
const assets=(await readdir('dist/assets')).map(f=>'/assets/'+f);
const version=assets.join('|');
await writeFile('dist/sw.js',`const CACHE='dayline-'+${JSON.stringify(version)};const BASE=new URL(self.registration.scope).pathname;const FILES=${JSON.stringify(['/', '/index.html','/manifest.webmanifest','/favicon.svg','/icons/icon-192.png','/icons/icon-512.png','/icons/apple-touch-icon.png','/icons/maskable-512.png',...assets])}.map(p=>BASE+p.slice(1));
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('dayline-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET'||new URL(e.request.url).origin!==location.origin)return;if(e.request.mode==='navigate'){e.respondWith(fetch(e.request).catch(()=>caches.match(BASE+'index.html')));return}e.respondWith(caches.match(e.request).then(cached=>cached||fetch(e.request)));});`);

