import type {Data} from '../types';
import {initial} from '../utils.ts';
import {seedEntry,validateBackup} from './migration.ts';
export const KEY='dayline-v1';
export const MIGRATION_BACKUP_KEY=KEY+'-before-v2';
interface Store {getItem(key:string):string|null;setItem(key:string,value:string):void;removeItem(key:string):void}
export function loadFromStore(storage:Store):Data {
 const raw=storage.getItem(KEY);if(!raw)return seedEntry(initial());
 const parsed=JSON.parse(raw);const data=validateBackup(parsed);
 if(parsed.version===1){if(!storage.getItem(MIGRATION_BACKUP_KEY))storage.setItem(MIGRATION_BACKUP_KEY,raw);seedEntry(data)}
 return data;
}
const store=()=>new URLSearchParams(location.search).has('test')?sessionStorage:localStorage;
// Preserve the original key across the rename. Failed validation never modifies it.
export const repository={clear(){store().removeItem(KEY);store().removeItem(MIGRATION_BACKUP_KEY)},load(){return loadFromStore(store())},save(data:Data){store().setItem(KEY,JSON.stringify(validateBackup(data)))},legacyBackup(){return store().getItem(MIGRATION_BACKUP_KEY)}};
