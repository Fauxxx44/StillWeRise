import type {Data} from '../types';
import {calories,logged} from '../utils.ts';
export const jsonBackup=(data:Data)=>JSON.stringify(data,null,2);
export function csvBackup(data:Data){
 const quote=(v:unknown)=>`"${String(v??'').replaceAll('"','""')}"`;
 const headers=['Record type','Date','Weight (kg)','Calories','Steps','Move kcal','Exercise minutes','Stand hours','Distance km','Flights climbed','Sleep hours','Status','Watch quality','Tags JSON','Foods JSON','Workouts JSON','Measurements JSON','Notes','Settings JSON','Saved meal JSON','Milestone JSON','Daily activity JSON','Manual calorie override'];
 const rows=Object.values(data.entries).filter(logged).sort((a,b)=>a.date.localeCompare(b.date)).map(e=>['day',e.date,e.weight,calories(e),e.steps,e.dailyActivity?.activeEnergy,e.dailyActivity?.exerciseMinutes,e.dailyActivity?.standHours,e.dailyActivity?.distanceKm,e.dailyActivity?.flightsClimbed,e.dailyActivity?.sleepHours,e.status,e.watchQuality,JSON.stringify(e.tags??[]),JSON.stringify(e.foods),JSON.stringify(e.activities),JSON.stringify(e.measurements),e.notes,'','','',JSON.stringify(e.dailyActivity??{}),e.calories]);
 rows.push(['settings',...Array(17).fill(''),JSON.stringify(data.settings),'','','','']);
 for(const meal of data.savedMeals)rows.push(['saved_meal',...Array(18).fill(''),JSON.stringify(meal),'','','']);
 for(const milestone of data.milestones)rows.push(['milestone',...Array(19).fill(''),JSON.stringify(milestone),'','']);
 return [headers.join(','),...rows.map(r=>r.map(quote).join(','))].join('\r\n');
}

