import type { Data, Entry, Food, Activity } from '../types';
import { foodSources, workoutSources } from '../types.ts';
const object = (v: unknown): v is Record<string, unknown> => !!v && typeof v === 'object' && !Array.isArray(v);
const numeric = (n: unknown, positive = false) => typeof n === 'number' && Number.isFinite(n) && (positive ? n > 0 : n >= 0);
function optionalNumber(n: unknown, positive = false) { if (n !== undefined && !numeric(n, positive)) throw Error('Invalid numeric value in backup.'); }
function choice(v: unknown, options: readonly unknown[], optional = false) { if (v === undefined && optional) return; if (!options.includes(v)) throw Error('Invalid option in backup.'); }
function validDate(date: string) { const d = new Date(date + 'T12:00:00Z'); return /^\d{4}-\d{2}-\d{2}$/.test(date) && Number.isFinite(d.getTime()) && d.toISOString().slice(0, 10) === date && Number(date.slice(0, 4)) >= 1900 && Number(date.slice(0, 4)) <= 2200; }
function food(v: unknown): asserts v is Food {
 if (!object(v) || typeof v.id !== 'string' || typeof v.name !== 'string') throw Error('Invalid food entry.');
 optionalNumber(v.calories); optionalNumber(v.protein); choice(v.source, foodSources, true);
 if (v.time !== undefined && (typeof v.time !== 'string' || !/^([01]\d|2[0-3]):[0-5]\d$/.test(v.time))) throw Error('Invalid food time.');
 if (v.estimated !== undefined && typeof v.estimated !== 'boolean') throw Error('Invalid food quality.');
}
function workout(v: unknown): asserts v is Activity {
 if (!object(v) || typeof v.id !== 'string' || typeof v.name !== 'string' || typeof v.note !== 'string') throw Error('Invalid workout entry.');
 optionalNumber(v.durationMinutes); optionalNumber(v.calories); choice(v.caloriesSource, workoutSources, true); choice(v.includedInDailyActiveEnergy, [true, false, 'unknown'], true);
}
export function validateBackup(value: unknown): Data {
 if (!object(value) || ![1, 2].includes(value.version as number) || !object(value.entries) || !object(value.settings) || !Array.isArray(value.milestones)) throw Error('Invalid backup structure.');
 const s = value.settings; choice(s.weightUnit, ['kg', 'lbs']); choice(s.theme, ['light', 'dark', 'system']); choice(s.pace, ['Slow', 'Moderate', 'Fast', 'Custom']);
 for (const k of ['targetWeight', 'calorieTarget', 'stepTarget', 'customPace', 'age', 'heightCm']) optionalNumber(s[k], true);
 optionalNumber(s.referenceSteps);
 for (const k of ['showReferenceSteps', 'proteinEnabled', 'advancedActivityEnabled']) if (s[k] !== undefined && typeof s[k] !== 'boolean') throw Error('Invalid setting.');
 for (const [date, e] of Object.entries(value.entries)) {
  if (!validDate(date) || !object(e) || e.date !== date || typeof e.notes !== 'string' || !Array.isArray(e.foods) || !Array.isArray(e.activities) || !object(e.measurements)) throw Error('Invalid daily entry.');
  optionalNumber(e.weight, true); optionalNumber(e.steps); optionalNumber(e.calories); if (e.steps !== undefined && !Number.isInteger(e.steps)) throw Error('Steps must be a whole number.');
  e.foods.forEach(food); e.activities.forEach(workout); Object.values(e.measurements).forEach(n => optionalNumber(n, true));
  choice(e.status, ['in_progress', 'completed'], true); choice(e.watchQuality, ['complete', 'partial', 'not_wearing', 'unknown'], true);
  if (e.tags !== undefined && (!Array.isArray(e.tags) || e.tags.some(t => typeof t !== 'string' || t.length > 80))) throw Error('Invalid day tags.');
  if (e.dailyActivity !== undefined) {
   if (!object(e.dailyActivity)) throw Error('Invalid activity summary.');
   for (const k of ['activeEnergy', 'exerciseMinutes', 'standHours', 'distanceKm', 'flightsClimbed', 'sleepHours']) optionalNumber(e.dailyActivity[k]);
   for (const k of ['standHours', 'sleepHours']) if (typeof e.dailyActivity[k] === 'number' && e.dailyActivity[k] > 24) throw Error('Hours must not exceed 24.');
   choice(e.dailyActivity.source, ['Apple Watch / iPhone', 'Manual', 'Other'], true);
  }
 }
 if (value.milestones.some(m => !object(m) || typeof m.id !== 'string' || !numeric(m.weight, true))) throw Error('Invalid milestone.');
 if (value.version === 2 && !Array.isArray(value.savedMeals)) throw Error('Invalid saved meals.');
 if (Array.isArray(value.savedMeals)) for (const m of value.savedMeals) { if (!object(m) || typeof m.id !== 'string' || typeof m.name !== 'string' || !Array.isArray(m.foods)) throw Error('Invalid meal template.'); m.foods.forEach(food); }
 const d = structuredClone(value) as unknown as Data; d.version = 2; d.savedMeals ??= [];
 if (value.version === 1) { d.settings.age ??= 21; d.settings.heightCm ??= 181; d.settings.referenceSteps ??= 6279; } d.settings.proteinEnabled ??= false; d.settings.advancedActivityEnabled ??= false; d.settings.showReferenceSteps ??= true;
 // An absent legacy calorie target may be intentionally disabled; never re-enable it.
 for (const e of Object.values(d.entries)) { e.status ??= 'in_progress'; e.watchQuality ??= 'unknown'; e.tags ??= []; for (const a of e.activities) { a.includedInDailyActiveEnergy ??= 'unknown'; a.caloriesSource ??= 'None'; } }
 if (value.version === 1) seedEntry(d);
 return d;
}
export function seedEntry(d: Data): Data { if (!Object.hasOwn(d.entries, '2026-10-03')) d.entries['2026-10-03'] = { date: '2026-10-03', weight: 105, foods: [], activities: [], measurements: {}, notes: '', status: 'in_progress', watchQuality: 'unknown', tags: [] } satisfies Entry;
 return d; }

