import type {Entry,Food,SavedMeal} from './types';
export function parseEstimate(text:string):{calories:number;name:string;estimated:true}|undefined {
 const n='(\\d{1,3}(?:[ ,]\\d{3})+|\\d+(?:[.,]\\d+)?)';
 const range=new RegExp(`${n}\\s*[-–—]\\s*${n}\\s*(?:kcal|ккал|calories)`,'gi');
 const ranges=[...text.matchAll(range)];const number=(s:string)=>Number(s.replace(/(?<=\d)[ ,](?=\d{3}(?:\D|$))/g,'').replace(',','.'));
 const singles=[...text.replace(range,'').matchAll(new RegExp(`${n}\\s*(?:kcal|ккал|calories)`,'gi'))];
 const labelled=[...text.matchAll(new RegExp(`(?:calories|калории)\\s*:\\s*${n}(?!\\s*[-–—])(?=\\s*(?:$|[.\\n]))`,'gi'))];
 if(ranges.length+singles.length+labelled.length!==1)return undefined;
 let value:number,matched:RegExpMatchArray;
 if(ranges.length){matched=ranges[0];const low=number(matched[1]),high=number(matched[2]);if(low>high)return undefined;value=Math.round((low+high)/2)}
 else if(singles.length){matched=singles[0];value=Math.round(number(matched[1]))}else{matched=labelled[0];value=Math.round(number(matched[1]))}
 if(!Number.isFinite(value)||value<0||/-\s*$/.test(text.slice(0,matched.index)))return undefined;
 const name=text.slice(0,matched.index).replace(/(?:estimated calories|estimated|approximately|approx\.?|calories|estimate)\s*:?\s*/gi,'').replace(/[\s—–:-]+$/g,'').trim();
 return {calories:value,name,estimated:true};
}
export function recentFoods(entries:Entry[],query:string):Food[]{const unique=new Map<string,Food>();for(const e of [...entries].sort((a,b)=>b.date.localeCompare(a.date)))for(const f of [...e.foods].reverse()){const key=f.name.trim().toLowerCase();if(key&&f.calories!==undefined&&!unique.has(key))unique.set(key,f)}return [...unique.values()].filter(f=>f.name.toLowerCase().includes(query.trim().toLowerCase())).slice(0,5)}
export function mealFoods(meal:SavedMeal):Food[]{return meal.foods.map(f=>({...f,id:crypto.randomUUID(),time:undefined}))}
