import type {Entry} from './types';
import {average,calories,change,moving,offset,windowEntries} from './utils.ts';
export const completeSteps=(entries:Entry[])=>average(entries.filter(e=>e.watchQuality==='complete').map(e=>e.steps));
export function calorieStats(entries:Entry[]){
 const completed=entries.filter(e=>e.status==='completed'&&calories(e)!==undefined),recorded=entries.filter(e=>calories(e)!==undefined);
 return {average:average((completed.length?completed:recorded).map(calories)),completedDays:completed.length,recordedDays:recorded.length,usesCompleted:completed.length>0};
}
export function activityTotals(entries:Entry[]){
 const exercise=entries.map(e=>e.dailyActivity?.exerciseMinutes).filter((n):n is number=>n!==undefined),durations=entries.flatMap(e=>e.activities).map(a=>a.durationMinutes).filter((n):n is number=>n!==undefined);
 return {averageMove:average(entries.map(e=>e.dailyActivity?.activeEnergy)),exerciseMinutes:exercise.length?exercise.reduce((a,b)=>a+b,0):undefined,averageStandHours:average(entries.map(e=>e.dailyActivity?.standHours)),workoutCount:entries.reduce((a,e)=>a+e.activities.length,0),workoutMinutes:durations.length?durations.reduce((a,b)=>a+b,0):undefined};
}
export function weeklyReview(entries:Entry[],end:string){
 const week=windowEntries(entries,end,7),prior=windowEntries(entries,offset(end,-7),7);
 return {averageWeight:average(week.map(e=>e.weight)),weightChange:change(entries,end,7),calories:calorieStats(week),steps:completeSteps(week),allSteps:average(week.map(e=>e.steps)),completeStepDays:week.filter(e=>e.watchQuality==='complete'&&e.steps!==undefined).length,completedDays:week.filter(e=>e.status==='completed').length,previousCalories:calorieStats(prior),...activityTotals(week)};
}
export function tagStatistics(entries:Entry[]){
 return [...new Set(entries.flatMap(e=>e.tags??[]))].map(tag=>{const relevant=entries.filter(e=>e.tags?.includes(tag)),steps=relevant.filter(e=>e.watchQuality==='complete'&&e.steps!==undefined),intake=relevant.filter(e=>e.status==='completed'&&calories(e)!==undefined);return {tag,stepDays:steps.length,calorieDays:intake.length,averageSteps:steps.length>=3?average(steps.map(e=>e.steps)):undefined,averageCalories:intake.length>=3?average(intake.map(calories)):undefined}}).filter(t=>t.averageSteps!==undefined||t.averageCalories!==undefined);
}
export function periodInsights(entries:Entry[],end:string){
 const period=windowEntries(entries,end,14),weightDays=period.filter(e=>e.weight!==undefined).length,first=[...period].sort((a,b)=>a.date.localeCompare(b.date))[0]?.date;
 const enough=!!first&&first<=offset(end,-13)&&weightDays>=8&&moving(entries,end)!==undefined&&moving(entries,offset(end,-7))!==undefined;
 return {enough,weightDays,calories:calorieStats(period),steps:completeSteps(period),completeStepDays:period.filter(e=>e.watchQuality==='complete'&&e.steps!==undefined).length,trend:enough?change(entries,end,7):undefined};
}
