import type {Entry,Data} from './types';
import {validateBackup} from './services/migration.ts';
export const today=()=>localDate(new Date());
export function localDate(d:Date){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
export function offset(date:string,n:number){const d=new Date(date+'T12:00:00');d.setDate(d.getDate()+n);return localDate(d)}
export const blank=(date:string):Entry=>({date,foods:[],activities:[],measurements:{},notes:'',status:'in_progress',watchQuality:'unknown',tags:[]});
export const calories=(e:Entry)=>e.calories??(e.foods.length&&e.foods.every(f=>f.calories!==undefined)?e.foods.reduce((s,f)=>s+f.calories!,0):undefined);
export const logged=(e:Entry)=>e.weight!==undefined||e.steps!==undefined||e.calories!==undefined||e.foods.length>0||e.activities.length>0||!!e.notes||Object.keys(e.measurements).length>0||Object.values(e.dailyActivity??{}).some(v=>typeof v==='number')||!!e.tags?.length||e.watchQuality!==undefined&&e.watchQuality!=='unknown'||e.status==='completed';
export function windowEntries(entries:Entry[],end:string,days:number){return entries.filter(e=>e.date<=end&&e.date>=offset(end,1-days))}
export function average(values:(number|undefined)[]){const v=values.filter((n):n is number=>n!==undefined);return v.length?v.reduce((a,b)=>a+b,0)/v.length:undefined}
export function moving(entries:Entry[],date:string){const v=windowEntries(entries,date,7).filter(e=>e.weight!==undefined);return v.length>=4?average(v.map(e=>e.weight)):undefined}
export function change(entries:Entry[],end:string,days:number){const a=moving(entries,end),b=moving(entries,offset(end,-days));return a!==undefined&&b!==undefined?a-b:undefined}
export const initial=():Data=>({version:2,entries:{},settings:{weightUnit:'kg',calorieTarget:2350,theme:'system',pace:'Moderate',age:21,heightCm:181,referenceSteps:6279,showReferenceSteps:true,proteinEnabled:false,advancedActivityEnabled:false},milestones:[],savedMeals:[]});
export const validate=validateBackup;
