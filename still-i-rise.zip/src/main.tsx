import React from 'react';import{createRoot}from'react-dom/client';import App from './App';import './style.css';import './refinement.css';
createRoot(document.getElementById('root')!).render(<React.StrictMode><App/></React.StrictMode>);
if('serviceWorker' in navigator&&import.meta.env.PROD){
 const register=()=>navigator.serviceWorker.register(import.meta.env.BASE_URL+'sw.js',{updateViaCache:'none'}).then(()=>navigator.serviceWorker.ready).then(()=>window.dispatchEvent(new CustomEvent('pwa-status',{detail:'ready'}))).catch(()=>window.dispatchEvent(new CustomEvent('pwa-status',{detail:'error'})));
 if(document.readyState==='complete')void register();else window.addEventListener('load',register,{once:true});
}
