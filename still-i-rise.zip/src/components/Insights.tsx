import type {Entry} from '../types';
import {periodInsights,tagStatistics,weeklyReview} from '../analytics';
import {Card,Stat} from '../components';
export default function Insights({entries,end,factor,unit}:{entries:Entry[];end:string;factor:number;unit:string}){
 const info=periodInsights(entries,end),tags=tagStatistics(entries),week=weeklyReview(entries,end);
 const fmt=(n:number|undefined,d=0)=>n===undefined?'More data needed':n.toLocaleString(undefined,{maximumFractionDigits:d,minimumFractionDigits:d});
 const intakeDays=info.calories.usesCompleted?info.calories.completedDays:info.calories.recordedDays;
 const calorieComparison=week.calories.completedDays>=4&&week.previousCalories.completedDays>=4&&week.calories.average!==undefined&&week.previousCalories.average!==undefined;
 if((!info.enough||intakeDays<7)&&!tags.length&&!calorieComparison)return null;
 return <Card title="Patterns, with perspective" extra={<span className="pill">Insights</span>}>
 {info.enough&&intakeDays>=7&&<><p className="eyebrow">LAST 14 DAYS</p><div className="insight-stats"><Stat label="Average recorded calories" value={fmt(info.calories.average)} unit="kcal/day"/><Stat label="Complete-data steps" value={fmt(info.steps)} unit="/day"/><Stat label="Weight trend" value={info.trend===undefined?'More data needed':`${info.trend>0?'+':''}${fmt(info.trend*factor,2)}`} unit={`${unit}/week`}/></div><p className="insight-copy">Your average weight {info.trend!<0?'decreased':info.trend!>0?'increased':'remained stable'} during this period while your average recorded intake was {fmt(info.calories.average)} kcal/day.</p><p className="muted small">{info.calories.usesCompleted?`${info.calories.completedDays} completed calorie days`:`${info.calories.recordedDays} recorded calorie days, including incomplete days`} · {info.completeStepDays} complete watch days. Observations only; no causal conclusions.</p></>}
 {calorieComparison&&<p className="insight-copy">Average recorded intake this week was {fmt(Math.abs(week.calories.average!-week.previousCalories.average!))} kcal {week.calories.average!<week.previousCalories.average!?'lower':'higher'} than the previous week. Based on completed days in each period.</p>}
 {tags.length>0&&<div className="tag-insights"><p className="eyebrow">BY DAY TAG · RECORDED HISTORY</p>{tags.map(t=><div key={t.tag}><span className="quality-badge">{t.tag}</span>{t.averageSteps!==undefined&&<p>Your average complete-data steps on {t.tag} days were {fmt(t.averageSteps)} ({t.stepDays} days).</p>}{t.averageCalories!==undefined&&<p>Average recorded intake on completed {t.tag} days was {fmt(t.averageCalories)} kcal ({t.calorieDays} days).</p>}</div>)}<p className="small muted">Each comparison needs at least 3 relevant days. Tags describe context, not causes.</p></div>}
 </Card>;
}
