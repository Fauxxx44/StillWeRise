export const foodSources = ['GPT estimate', 'Package / label', 'Restaurant', 'Manual', 'Other'] as const;
export const workoutSources = ['Apple Watch', 'Treadmill', 'Exercise machine', 'Manual estimate', 'None'] as const;
export type WatchQuality = 'complete' | 'partial' | 'not_wearing' | 'unknown';
export interface Food { id: string; name: string; calories?: number; protein?: number; time?: string; source?: typeof foodSources[number]; estimated?: boolean }
// The original activity array now represents workouts; its energy never contributes to Move.
export interface Activity { id: string; name: string; durationMinutes?: number; note: string; calories?: number; caloriesSource?: typeof workoutSources[number]; includedInDailyActiveEnergy?: boolean | 'unknown' }
export interface DailyActivity { activeEnergy?: number; exerciseMinutes?: number; standHours?: number; distanceKm?: number; flightsClimbed?: number; sleepHours?: number; source?: 'Apple Watch / iPhone' | 'Manual' | 'Other' }
export interface Entry { date: string; weight?: number; calories?: number; steps?: number; foods: Food[]; activities: Activity[]; measurements: Record<string, number>; notes: string; status?: 'in_progress' | 'completed'; watchQuality?: WatchQuality; dailyActivity?: DailyActivity; tags?: string[] }
export interface Settings { weightUnit: 'kg' | 'lbs'; targetWeight?: number; calorieTarget?: number; stepTarget?: number; theme: 'light' | 'dark' | 'system'; pace: 'Slow' | 'Moderate' | 'Fast' | 'Custom'; customPace?: number; age?: number; heightCm?: number; referenceSteps?: number; showReferenceSteps?: boolean; proteinEnabled?: boolean; advancedActivityEnabled?: boolean }
export interface SavedMeal { id: string; name: string; foods: Food[] }
export interface Data { version: 2; entries: Record<string, Entry>; settings: Settings; milestones: { id: string; weight: number }[]; savedMeals: SavedMeal[] }
